+++
author = "coucou"
title = "C语言——杂项"
date = "2023-08-01"
description = "C语言专题之杂项"
categories = [
    "C语言"
]
tags = [
    "C语言","杂项"
]
+++
![](1.jpg)